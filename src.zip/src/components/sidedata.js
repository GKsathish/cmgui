import React from "react";
import Registation from "./Registation";
import AppRegistrationIcon from '@mui/icons-material/AppRegistration';
import LoginIcon from '@mui/icons-material/Login';

const sidedata =[

    {
        title:"Login",
        icon:<LoginIcon/>,
        link:"/",
     },

 {
    title:Registation,
    icon:<AppRegistrationIcon/>,
    link:"/Registation",
 }
];

export default sidedata